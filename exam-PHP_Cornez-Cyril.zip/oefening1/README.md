## MAGIC 8-BALL

###### (4 punten)

- Schrijf in index.php code die ervoor zorgt dat de pagina zich gedraagt als een Magic 8 Ball:

- De pagina toont initieel enkel een knop met label "ASK 8-BALL".

- Na klik herlaadt dezelfde pagina en wordt wordt willekeurig (!) één van volgende antwoorden getoond:

  - It is certain.
  - It is decidedly so.
  - Without a doubt.
  - Yes definitely.
  - You may rely on it.
  - As I see it, yes.
  - Most likely.
  - Outlook good.
  - Yes.
  - Signs point to yes.
  - Reply hazy, try again.
  - Ask again later.
  - Better not tell you now.
  - Cannot predict now.
  - Concentrate and ask again.
  - Don't count on it.
  - My reply is no.
  - My sources say no.
  - Outlook not so good.
  - Very doubtful.

- Toon onder het antwoord opnieuw de knop, maar pas het label aan zodat er nu "ASK AGAIN" te lezen staat.

- De pagina toont nooit 2x achter elkaar hetzelfde antwoord.

- Schrijf de code zo performant mogelijk, hou rekening met leesbaarheid en documenteer waar nodig!

- Succes!
